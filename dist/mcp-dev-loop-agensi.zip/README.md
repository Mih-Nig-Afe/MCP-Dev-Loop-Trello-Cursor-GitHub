# Trello Dev Loop — Skill Package

Thank you for purchasing **Trello Dev Loop** on Agensi.io!

## Quick Setup (1 Minute)

### macOS / Linux:
```bash
./bin/setup.sh
```

### Windows (PowerShell):
```powershell
.\bin\setup.ps1
```

The setup script will prompt for your Trello API credentials and automatically configure your primary agent (Cursor, Claude Desktop, Claude Code, Windsurf, or VS Code Copilot).

## Manual Configuration

If you prefer manual setup, inspect the `configs/` directory for your agent:
- **Cursor**: `configs/cursor/mcp.json`
- **Claude Desktop**: `configs/claude-desktop/claude_desktop_config.json`
- **Claude Code**: `claude mcp add trello node "${PWD}/dist/trello-mcp.cjs"`
- **Windsurf**: `configs/windsurf/mcp_config.json`
- **VS Code Copilot**: `configs/vscode-copilot/mcp.json`

## First Commands in Agent Chat

```
analyze my assigned tasks
analyze ticket <ticket-id>
implement ticket <ticket-id>
create pr for ticket <ticket-id>
mark done
```

Read `SKILL.md` for the full command reference and safety guidelines.
